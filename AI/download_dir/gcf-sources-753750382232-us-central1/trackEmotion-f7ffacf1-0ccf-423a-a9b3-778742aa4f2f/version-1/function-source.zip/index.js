const functions = require("firebase-functions");
const cors = require("cors")({origin: true});
// The Firebase Admin SDK to access Firestore.
const admin = require("firebase-admin");
admin.initializeApp();


exports.trackEmotion = functions.https.onRequest((req, res) => {
  cors(req, res, () => {
    const userName = req.body.username;
    const emotion = req.body.emotion;
    const date = req.body.date;
    const imageBase64 = req.body.imageBase64;
    // check is exist
    const usersRef =admin.firestore().collection("patients").doc(userName);
    usersRef.get()
        .then((docSnapshot) => {
          const dataToAdd = admin.firestore.FieldValue.arrayUnion({
            emotion, date, imageBase64,
          });
          if (docSnapshot.exists) {
            // add to firebase
            usersRef.update({emotions: dataToAdd}).then((ref) => {
              console.log("added to firebase", ref.writeTime);
              res.status(200).send("firebase data added created.");
              return;
            });
          } else {
            // add to firebase
            usersRef.set({emotions: dataToAdd}).then((ref) => {
              console.log("added to firebase", ref.writeTime);
              res.status(200).send("firebase data added created.");
              return;
            });
          }
        });
  });
});
